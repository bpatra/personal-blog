The 21 time series in files CCSeries*.tsv 
while the set D using setD.dat(see related article Sequential Quantile Prediction of Time Series BIAU G. PATRA B. ).
all files can be openend with a text editor (like notepad or notepad++)

PATRA Benoit